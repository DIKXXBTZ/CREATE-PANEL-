require(`./config.js`)

const { baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia } = require("@adiwajshing/baileys")

const { getGroupAdmins, fetchJson, reSize, generateProfilePicture, sleep } = require("./functions.js")

const { exec, spawn, execSync } = require("child_process")

const cheerio = require("cheerio")

const chalk = require("chalk")

const util = require("util")

const axios = require("axios")

const fs = require("fs")

const syntaxerror = require("syntax-error")

const Jimp = require("jimp")

const PhoneNumber = require("awesome-phonenumber")

const speed = require("performance-now")

const moment = require("moment-timezone")

const owner = JSON.parse(fs.readFileSync('./owner.json'))

const audionya = fs.readFileSync('./music.mp3')

module.exports = client = async (client, msg, chatUpdate, store) => {

try {

const type = getContentType(msg.message)

const content = JSON.stringify(msg.message)

const from = msg.key.remoteJid

const quoted = msg.quoted ? msg.quoted : msg

const mime = (quoted.msg || quoted).mimetype || ''

const body = (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type == 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type == 'documentMessage') && msg.message.documentMessage.caption ? msg.message.documentMessage.caption : (type == 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type == 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : (type == 'buttonsResponseMessage' && msg.message.buttonsResponseMessage.selectedButtonId) ? msg.message.buttonsResponseMessage.selectedButtonId : (type == 'templateButtonReplyMessage') && msg.message.templateButtonReplyMessage.selectedId ? msg.message.templateButtonReplyMessage.selectedId : ''

const budy = (typeof msg.text == 'string' ? msg.text : '')

const prefix = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@*+,.?=''():√%¢£¥€π¤ΠΦ_&><!`™©®Δ^βα~¦|/\\©^]/gi) : '.'

const isCmd = body.startsWith(prefix)

const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''

const args = body.trim().split(/ +/).slice(1)

const text = q = args.join(" ")

const isGroup = from.endsWith('@g.us')

const groupMetadata = isGroup? await client.groupMetadata(msg.chat).catch(e => {}) : ""

const groupName = isGroup? groupMetadata.subject : ""

const groupOwner = isGroup? groupMetadata.owner : ""

const participants = isGroup? await groupMetadata.participants : ""

const groupAdmins = isGroup? await participants.filter(v => v.admin !== null).map(v => v.id) : ""

const groupMembers = isGroup? groupMetadata.participants : ""

const isGroupAdmins = isGroup? groupAdmins.includes(msg.sender) : false

const botNumber = await client.decodeJid(client.user.id)

const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false

const sender = msg.key.fromMe ? (client.user.id.split(':')[0]+'@s.whatsapp.net' || client.user.id) : (msg.key.participant || msg.key.remoteJid)

const senderNumber = sender.split('@')[0]

const pushname = msg.pushName || `${senderNumber}`

const isBot = botNumber.includes(senderNumber)

const isOwner = owner.includes(senderNumber) || isBot

const jamwib = await moment.tz('Asia/Jakarta').format('HH')

const menitwib = await moment.tz('Asia/Jakarta').format('mm')

const detikwib = await moment.tz('Asia/Jakarta').format('ss')

const kays = (`Jam: ${jamwib} Menit: ${menitwib} Detik: ${detikwib}`)

const getBuffer = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (err) {
		return err
	}
}

const ss = await getBuffer(`https://telegra.ph/file/6e85270a45fe1847de2fb.jpg`)

function eror() {

const crtr = owner[0] + "@s.whatsapp.net"

client.sendMessage(from, { text : `Maaf Terjadinya Error Kak Harap Lapor Ke @${crtr.split("@")[0]}`, mentions: [crtr] }, { quoted : msg })

}

const parseMention = (text = '') => {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const makeid = (length) => {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
  result += characters.charAt(Math.floor(Math.random() *
  charactersLength));
    }
    return result
}

const reply = (teks) => {

client.sendMessage(from, { text : teks }, { quoted : msg })

}

const sticWait = () => {
let ano = fs.readFileSync('./wait.webp')
client.sendMessage(from, { sticker: ano }, { quoted: msg })
}

if (isCmd && msg.isGroup) { 

console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Group Chat"), chalk.bold('[' + args.length + ']')); 

}

if (isCmd && !msg.isGroup) { 

console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Private Chat"), chalk.bold('[' + args.length + ']')); 

}

function khususOwner() {
reply("Kamu Siapa? Owner Ku Bukan Kalau Bukan Jangan Gunain Command Ini Ya")
}

switch (command) {

case "pushkontak":
if (!isOwner) return khususOwner()
if (!q) return reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} idgc|tekspushkontak`)
await sticWait()
const metadata2 = await client.groupMetadata(q.split("|")[0])
const halss = metadata2.participants
for (let mem of halss) {
client.sendMessage(`${mem.id.split('@')[0]}` + "@s.whatsapp.net", { text: q.split("|")[1] })
await sleep(5000)
}
break

case "menu": case "menupushkontak": {
if (!isOwner) return khususOwner()
let getGroups = await client.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP ANDA*\n\nTotal Group : ${anu.length} GROUP\n\n`
for (let x of anu) {
let metadata2 = await client.groupMetadata(x)
teks += `❏  ${metadata2.subject}\n┠─ *ID :* ${metadata2.id}\n┠─ *STATUS :* GROUP\n╰────| ANGGOTA : ${metadata2.participants.length}\n\n`
}
reply(teks + `Untuk Penggunaan Silahkan Ketik\nCommand ${prefix}pushkontak id|teks\n\nPOWER BY *© nama lu⚡*`)
}
break

default:
}
} catch (err) {
console.log(util.format(err))
let e = String(err)
client.sendMessage("nomor owner@s.whatsapp.net", {text:e})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})