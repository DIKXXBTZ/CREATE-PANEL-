global.ownerNumber = ["udh pake nomor owner@s.whatsapp.net"]


global.nomerOwner = "nomor owner"


global.nomorOwner = ['nomer owner']


global.namaCreator = "Creator udh pake nama lu"


global.namaBot = "nama bot lu⚡"


global.gopayno = "nomor gopay,jika ga ada ga usah di isi"


global.ovono = "nomor ovo,jika ga ada ga usah di isi"


global.danano = "nomor dana,jika ga ada ga usah di isi"


global.shopeepayno = "nomor shoppe,jika ga ada ga usah di isi"


const chalk = require("chalk")
const fs = require("fs")
let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})